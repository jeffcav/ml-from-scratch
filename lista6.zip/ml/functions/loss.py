class CrossEntropyLoss:
    def __init__(self) -> None:
        pass

class MeanSquareErrorLoss:
    def __init__(self) -> None:
        pass
